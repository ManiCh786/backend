<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class UserController extends Controller
{

    public function userInfo()
    {
        return User::all();
        // $userInfo = auth()->user();
        // return $userInfo;
        // return response()->json(['User Details ' => $userInfo], 200);
    }
    public function get()
    {
        $userInfo = User::join('roles', 'users.roleId', '=', 'roles.roleId')
        ->select('roles.*', 'users.*')
        ->first();
        return User::all();
    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'password' => 'required|min:6'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => "Field Values are not valid"], 200);
        }

        $data = [
            'email' => $request->email,
            'password' => $request->password
        ];

        if (auth()->attempt($data)) {
            $userInfo = User::join('roles', 'users.roleId', '=', 'roles.roleId')
                ->select('roles.*', 'users.*')
                ->where('email', $request->input('email'))
                ->where('password', Hash::check($request->input('password'), 'password'))
                ->first();
            $token = $userInfo->createToken('userLoginToken')->accessToken;
            return response()->json(['message' => 'Login Approved', 'token' => $token, 'email' => auth()->user()->email, 'accountType' => $userInfo->roleName], 200);
        } else {

            return response()->json([
                'errors' => "Something went wrong"
            ], 200);
        }
    }
}